Alien Isolation DX11 - Executable Version {Unknown}
ShaderToggler Config  - Jordan
If help is needed, or if the configuration file is broken, please contact @jorban on the PGHub Discord - https://discord.gg/wY49KMxjHT

--------------------------------------

Known Issues:
Not all bloom is removed. Nothing I can do about it without causing issues.
Not all smoke/fog could be removed without destroying the game.

--------------------------------------

Changelog:

v1.0 - OCT 01, 2024
Created UI removal group
Created Ambient Lighting removal group
Created Lens Flare removal group
Created Smoke & Fog removal group

--------------------------------------
The Witcher 3: Wild Hunt DX12 - Executable Version 4.0.1.37654
ShaderToggler Config  - Jordan
If help is needed, or if the configuration file is broken, please contact @jorban on the PGHub Discord - https://discord.gg/wY49KMxjHT

--------------------------------------

Known Issues:
Not all bloom is removed. Nothing I can do about it without causing issues. Most bloom should be removed, but you can also just disable that in-game

--------------------------------------

Changelog:

v1.0 - AUG 29, 2024
Created UI removal group
Created cutscene removal group
Created bloom removal group

--------------------------------------
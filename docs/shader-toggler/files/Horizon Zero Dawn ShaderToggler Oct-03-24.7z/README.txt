Horizon: Zero Dawn DX12 - Executable Version 1.0.11.14
ShaderToggler Config  - Jordan
If help is needed, or if the configuration file is broken, please contact @jorban on the PGHub Discord - https://discord.gg/wY49KMxjHT

--------------------------------------

Known Issues:
Not all bloom is removed. Nothing I can do about it without causing issues. 
When disabling bloom, it will take ~15 seconds before it completely disappears.
Not all smoke/fog could be removed without destroying the game.

--------------------------------------

Changelog:

v1.1 OCT 03, 2024
Changed keybinds to better reflect ordering
Renamed shader removal groups to better reflect what they're removing
Added shaders to Particle removal group
Added shaders to Smoke/Fog removal group
Added shaders to Hologram removal Group
Added shaders to Lens Flares removal group

---

v1.0 - AUG 31, 2024
Created UI removal group
Created Particles removal group
Created Smoke/Fog removal group
Created Projected Water Caustics removal group
Created Bloom removal group
Created 2D Hologram removal group
Created 2D Hologram Lighting removal group
Created Lens Flares removal group

--------------------------------------
Deep Rock Galactic - Executable Version 4.27.2.0
ShaderToggler Config  - Jordan
If help is needed, or if the configuration file is broken, please contact @jorban on the PGHub Discord - https://discord.gg/wY49KMxjHT

--------------------------------------

Known Issues:
Not all Ambient Occlusion could be removed.
Removing Screen Space Reflections will remove some GI in-game.

--------------------------------------

Changelog:

v1.0 - AUG 31, 2024
Created Screen Space Reflections removal group
Created Smoke/Fog removal group
Created Ambient Occlusion removal group
Created Ground Clutter/Decals removal group
Created UI removal group
Created Point Lights removal group

--------------------------------------